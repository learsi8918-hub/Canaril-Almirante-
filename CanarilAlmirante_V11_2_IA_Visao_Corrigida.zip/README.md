# Canaril Almirante V11.2 — IA de Visão
Versão corrigida: o painel de IA é inserido automaticamente na ficha mesmo quando os títulos/âncoras da versão anterior mudam.
O servidor continua usando a Secret OPENAI_API_KEY no Cloudflare; nunca coloque a chave no APK.
